def is_json():
    pass

def _json_helper():
    pass
