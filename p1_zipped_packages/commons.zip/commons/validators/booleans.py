def is_boolean():
    pass

def _boolean_helper():
    pass
