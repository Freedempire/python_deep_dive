def is_date():
    pass

def _date_helper():
    pass
